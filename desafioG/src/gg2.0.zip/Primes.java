public class Primes {

    int start, end, values = 0;
    int[] arrayOfPrimes;

    public Primes(int start, int end){
        this.start = start;
        this.end = end;
        this.arrayOfPrimes = arrayOfPrimes(start, end);
    }

    public boolean atLeastTwoPrimes(){
        return values >= 2;
    }

     private boolean isPrime(int n){

        int d = 2;
        double limit = Math.sqrt(n);

        if(n==1){
            return false;
        }
        else {
            while (n % d != 0 && d <= limit) {
                d++;
            }
            return d > limit;
        }
    }

    private int[] arrayOfPrimes(int start, int end){

        int[] arrayOfPrimes = new int[end];

        //debug
//        System.out.printf("Start: %d\n",start);
//        System.out.printf("End: %d\n",end);

        for (int i = start; i <= end; i++){
            if (isPrime(i)){

                arrayOfPrimes[this.values] = i;

                //debug
//                System.out.printf("Array %d: %d\n",this.values, i);

                this.values++;
            }
        }
        return arrayOfPrimes;
    }

    public int lowerDistance(){

        int distance = this.end;
        int newDistance;

        for(int i = 0;  i < this.values-1; i++){
            int a = i + 1;
            //debug
//            System.out.printf("a position: %d, value: %f\n",a,this.arrayOfPrimes[a]);
//            System.out.printf("i position: %d, value: %f\n",i,this.arrayOfPrimes[i]);
            //
            newDistance = this.arrayOfPrimes[a] - this.arrayOfPrimes[i];
            //debug
//            System.out.printf("newDistance: %f\n",newDistance);
            //
            //debug
//            System.out.printf("old distance: %f\n",distance);
            distance = Math.min(newDistance, distance);
            //debug
//            System.out.printf("new distance: %f\n",distance);
        }

        return distance;
    }

    public int higherDistance(){

        int distance = 0;
        int newDistance;

        for(int i = 0;  i < this.values; i++){
            int a = i + 1;
            newDistance = this.arrayOfPrimes[a] - this.arrayOfPrimes[i];
            distance = Math.max(newDistance, distance);
        }
        return distance;
    }
}
