public class Primes {

    int start, end, values = 0;
    double[] arrayOfPrimes;

    public Primes(int start, int end){
        this.start = start;
        this.end = end;
        this.arrayOfPrimes = arrayOfPrimes(start, end);
    }

    public boolean atLeastTwoPrimes(){
        return values >= 2;
    }

     private boolean isPrime(int n){

        int d = 2;
        double limit = Math.sqrt(n);

        if(n==1){
            return false;
        }
        else {
            while (n % d != 0 && d <= limit) {
                d++;
            }
            return d > limit;
        }
    }

    private double[] arrayOfPrimes(int start, int end){

        double[] arrayOfPrimes = new double[end];

        //debug
//        System.out.printf("Start: %d\n",start);
//        System.out.printf("End: %d\n",end);

        for (int i = start; i <= end; i++){
            if (isPrime(i)){

                arrayOfPrimes[this.values] = i;

                //debug
//                System.out.printf("Array %d: %d\n",this.values, i);

                this.values++;
            }
        }
        return arrayOfPrimes;
    }

    public double lowerDistance(){

        double distance = this.end;
        double newDistance;

        for(int i = 0;  i < this.values-1; i++){
            int a = i + 1;
            //debug
//            System.out.printf("a position: %d, value: %f\n",a,this.arrayOfPrimes[a]);
//            System.out.printf("i position: %d, value: %f\n",i,this.arrayOfPrimes[i]);
            //
            newDistance = this.arrayOfPrimes[a] - this.arrayOfPrimes[i];
            //debug
//            System.out.printf("newDistance: %f\n",newDistance);
            //
            //debug
//            System.out.printf("old distance: %f\n",distance);
            distance = Math.min(newDistance, distance);
            //debug
//            System.out.printf("new distance: %f\n",distance);
        }

        return distance;
    }

    public double higherDistance(){

        double distance = 0;
        double newDistance;

        for(int i = 0;  i < this.values; i++){
            int a = i + 1;
            newDistance = this.arrayOfPrimes[a] - this.arrayOfPrimes[i];
            distance = Math.max(newDistance, distance);
        }

        return distance;
    }
}
