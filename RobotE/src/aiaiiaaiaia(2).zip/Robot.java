public class Robot {

    //setting constants
    private static final int N = 100;
    private static final int M = 100;
    private static final int MIN = 1;

    private static final int UP = 1;
    private static final int DOWN = 2;
    private static final int RIGHT = 3;
    private static final int LEFT = 4;

    //setting variables
    private int x, y, aut;

    public Robot(int x, int y, int aut){
        //constructor
        this.x = x;
        this.y = y;
        this.aut = aut;
    }

    public int getX(){
        return this.x;
    }

    public int getY(){
        return this.y;
    }

    public int getAut(){return this.aut;}

    public boolean willCollide(Robot other, int distance, int direction){
        //returns true if robots collide

        int ox = other.getX();
        int oy = other.getY();

        boolean collision = false;

        int dx = this.x - ox;
        int dy = this.y - oy;

        switch (direction){
            case UP ->
                collision = ((dx == 0) && (dy < 0) && ((y + distance) >= oy ));
            case DOWN ->
                collision = ((dx == 0) && (dy > 0) && ((y - distance) <= oy ));
            case RIGHT ->
                collision = ((dy == 0) && (dx < 0) && ((x + distance) >= ox ));
            case LEFT ->
                collision = ((dy == 0) && (dx > 0) && ((x - distance) <= ox ));
        }
        return collision;
    }

    public boolean hasBattery(int distance,int aut){
        return (distance <= aut);
    }

    //assuming robots won't collide
    //checks if robot has autonomy to do so
    public int move(int distance, int direction, int x_, int y_, int aut) {

        int old_y, old_x, movey, movex;

        old_y = y_;
        old_x = x_;
        movey = y_;
        movex = x_;

        int moved;

        switch (direction) {
            case UP ->
                movey = Math.min(movey + distance, M);
            case DOWN ->
                movey = Math.max(movey - distance, MIN);
            case RIGHT ->
                movex = Math.min(movex + distance, N);
            case LEFT ->
                movex = Math.max(movex - distance, MIN);
        }

        moved = Math.abs(movey - old_y) + Math.abs(movex - old_x);


        return moved;
    }


    public int closestWall(Robot other){

        int rX, rY;

        rX = this.x;
        rY = this.y;

        int horizontal, vertical, DIRECTION, hdirection, vdirection;

        //checking which side is the closest (vertical)
        if (rY >= (M/2)){
            vdirection = UP;
        } else {vdirection = DOWN;}

        //checking which side is the closest (horizontal)
        if (rX >= (N/2)){
            hdirection = RIGHT;
        } else {hdirection = LEFT;}

        //calculating distance to closest wall (vertical)
        if (vdirection == UP) {
            vertical = Math.abs(rY - M);
        }
        else {
            vertical = Math.abs(rY - MIN);
        }
        //calculating distance to closest wall (vertical)
        if (hdirection == RIGHT) {
            horizontal = Math.abs(rX - N);
        }
        else {
            horizontal = Math.abs((rX - MIN));
        }

        /*
            vertical checks if robot will collide
            if does and is at position y == (M/2) robot will automatically return DOWN
            if it does and is at any other point, vertical value = -1
        */
        if (this.willCollide(other, vertical, vdirection)) {
            if (rY == (M/2)) {
                vdirection = DOWN;
            } else {
                vertical = -1;
            }
        }
        /*
            horizontal checks if robot will collide
            if it does and x == N/50 hdirection is equal to the other direction
            if it does and x =/= horizontal value equals to -1
        */
        if (this.willCollide(other, horizontal, hdirection)) {
            if (rX == (N/2)) {
                hdirection = LEFT;
            } else {
                horizontal = -1;
            }
        }

        //checks if there is a collision
        if ((horizontal>0)&&(vertical>0)) {

            //considering there isn't a collision, checks which side is closest to wall
            if (horizontal > vertical) {
                DIRECTION = vdirection;
            }
            //if they are at the same distance, horizontal int are lower and have priority
            else if (horizontal == vertical) {
                DIRECTION = vdirection;
            }
            else {
                DIRECTION = hdirection;
            }
        }
        else {

            //considering there is a collision, returns other side
            if (vertical < 0){
                DIRECTION = hdirection;
            }
            else {
                DIRECTION = vdirection;
            }
        }
        return DIRECTION;
    }

    public boolean robotReturn(Robot other,int aut ,int x ,int y){

        int direction = this.closestWall(other);
        int distance;

        switch (direction) {
            case 1 -> distance = Math.abs(y - M);
            case 2 -> distance = Math.abs(y - MIN);
            case 3 -> distance = Math.abs(x - N);
            case 4 -> distance = Math.abs(x - MIN);
            default -> distance = 0;
        }

       return this.hasBattery(distance,aut);
    }

    public boolean survey(Robot other, int xi, int yi){

        boolean firstMovement, returning;

        //setting up distance and direction to use move
        int x = xi - this.x;
        int y = yi - this.y;

        int xDistance = Math.abs(x);
        int yDistance = Math.abs(y);

        int xDirection, yDirection;

        if (y >= 0){
            yDirection = 1;
        }
        else {
            yDirection = 2;
        }

        if (x >= 0){
            xDirection = 3;
        }
        else {
            xDirection = 4;
        }

        //checking collision
        //if survey and both robots are in a line
        if (x == 0){
            if (this.willCollide(other, yDistance, yDirection)){
                return false;
            }
        }
        else if (y == 0) {
            if (this.willCollide(other, xDistance, xDirection)){
                return false;
            }
        }
        if ((other.getX()==xi)&&(other.getY()==yi)){
            return false;
        }

        int moveX, moveY;

        Robot r3 = new Robot(this.x,this.y,this.aut);

        moveX = r3.move(xDistance,xDirection,r3.getX(),r3.getY(),r3.getAut());
        moveY = r3.move(yDistance,yDirection,r3.getX(),r3.getY(),r3.getAut());

        firstMovement = ((moveX>=0)&&(moveY>=0));

        //checking if returning is possible
        returning = r3.robotReturn(other,r3.getAut(),r3.getX(),r3.getY());

        //checking if everything is possible
        if(firstMovement){
            return returning;
        }
        return false;
    }
}