
public class Battleships {
    /**
     * @authors Diogo Antunes(67763) & Felipe Magno(67994)
     * Handles information concerning the game's functions
     * Middle-man between Main and the Player objects
     */
    // constants
    private static final char WATER = '.';
    private static final int HIT = 100;
    private static final int BAD_HIT = -30;
    private static final int NONE = -1;


    static final int ELIMINATED_PLAYER_CASE = 4;
    static final int INVALID_COORS_CASE = 5;
    static final int INVALID_PLAYER_CASE = 3;
    static final int SELF_HIT_CASE = 2;
    static final int VALID = 1;


    // instance variables
    private int playerTurnIdx;
    private int winnerIdx;
    private int setupPlayerIdx;
    private Player[] players;

    /**
     * Constructor
     * @param numOfPlayers the number of participating players (int)
     * @pre: numOfPlayers > 1
     */
    public Battleships(int numOfPlayers) {
        this.players = new Player[numOfPlayers];
        winnerIdx = NONE;
        //Index of the most recently finished player during setup-Phase
        setupPlayerIdx = 0;

    }
    // methods

    /**
     * Adds a valid player to the players array to participate in the game
     * @param playerName the unique name attribute of the new Player object (String)
     * @param playerIdx the position number of the player, starting with 1   (int)
     * @pre: !playerName.equals(null) && fleetNum > 0 && fleetRows > 0 && fleetCols > 0
     */
    public void addPlayer(String playerName,int playerIdx, int layoutNum) {
        players[playerIdx] = new Player(playerName, layoutNum);
    }

    /**
     * Returns FleetIterator of the Player object with name equal to playerName
     * @param playerName name of player to get fleet (String)
     * @pre:  hasPlayer(playerName)
     * @return an Object to iterate over the lines of the player's fleet
     */
    public FleetIterator getFleet(String playerName) {
        return getPlayer(playerName).getFleet();
    }
    /**
     * Returns fleet of the Player object with name equal to playerName
     * @param sorted whether output is expected to be sorted (boolean)
     * @pre:  hasPlayer(playerName) == true && !fleet.equals(null);
     * @return an Object to iterate over players
     */
    public PlayerIterator getPlayerIterator(boolean sorted) {
        return new PlayerIterator(players, sorted);
    }

    /**
     * Returns value of the maximum layoutNum used by the players
     * @pre: players.length > 0
     * @return layout number of the last Player Object in players
     */
    public int getMaxLayoutNum(){
        return players[players.length-1].getLayoutNum();
    }

    /**
     * Returns the name of the next player to attack
     * @pre:  getNextPlayer() != null && !playerName.equals(null);
     * @return the current turn player's name,
     */
    public String getNextPlayerName() {
        String playerName = getNextPlayer().getName();
        return playerName;
    }
    /**
     * Returns score of the Player object with name equal to playerName
     * @param playerName name of player to retrieve score value (String)
     * @pre:  hasPlayer(playerName) == true && score != null;
     * @return the current score of the retrieved player
     */
    public int getScore(String playerName) {
        int score = getPlayer(playerName).getScore();
        return score;
    }
    /**
     * Searches Player objects within BattleShips object
     * Checks if there
     * @param playerName name of the player being searched for (String)
     * @pre:  !playerName.equals(null)
     * @return boolean value, represents whether either player contains
     * a name value equal to the one given
     */
    public boolean hasPlayer(String playerName) {
        boolean found = false;
        int i = 0;
        int size = players.length;
        while (!found && i < size) {
            found = (playerName.equals(players[i++].getName()));
        }
        return found;
    }

    /**
     * Returns whether there is a winner
     * @pre: winnerIdx == NONE || winnerIdx < players.length-1
     * @return boolean value representing if the game has ended
     */
    public boolean hasWinner() {
        return winnerIdx != NONE;
    }
    /**
     * Returns the winning Player's name
     * @pre: winnerIdx == NONE || winnerIdx < players.length
     * @return String name of winner player
     */
    public String getWinnerName() {
        return players[winnerIdx].getName();
    }

    /**
     * During set-up phase of the game: carries out an entire player loop
     * to create layouts for players using a specific layout number
     * @param layoutNum the number of the layout from the input file (int)
     * @param rows the number of rows in the layout referred to      (int)
     * @param cols the target col position of the shot (int)
     */
    public void processLayout(int layoutNum, int rows, int cols) {
        int limit = players.length;
        int i = setupPlayerIdx;
        while (i < limit && players[i].getLayoutNum() == layoutNum){
            Player player = players[i];
            if(player.getLayoutNum() == layoutNum) {
                player.setFleet(rows, cols);
            }
            i++;
        }
    }

    /**
     * Set-up phase of the game,
     * sets a row for players using the same layout number
     * @param layoutNum the number of the layout from the input file (int)
     * @param row the row position in the layout referred to         (int)
     * @param rows the number of rows in the layout referred to      (int)
     * @param line row that will be added from the input file     (String)
     */
    public void processFleetLine(int layoutNum, int row , int rows, String line){
        int j = setupPlayerIdx;
        while (j < players.length && players[j].getLayoutNum() == layoutNum) {
            players[j].addLine(line, row);
            j++;
        }
        if (row == rows-1){
            setupPlayerIdx = j;
        }
    }

    /**
     * Main game action
     * Opposing Player's fleet is shot at
     * Change in points and target's fleet are carried out
     * @param rowPos the target row position of the shot (int)
     * @param colPos the target col position of the shot (int)
     * @pre:  hasPlayer(targetName)
     * && shotIsValid(rowPos, colPos, targetName)
     */
    public void shoot(int rowPos, int colPos, String targetName) {
        int rowIndex = rowPos-1;
        int colIndex = colPos-1;
        Player attacker = getNextPlayer();
        Player opponent = getPlayer(targetName);
        boolean isSunk = opponent.isShipSunk(rowIndex, colIndex);
        int shipSize = opponent.checkShot(rowIndex, colIndex);

        //Apply score to the attacking player
        //Assumes that by hitting water, score change is always 0
        if (isSunk) {
            attacker.addScore(shipSize * BAD_HIT);
        } else {
            attacker.addScore(shipSize * HIT);
        }
        int pastTurnIdx = playerTurnIdx;
        changeTurn();
        updateWinStatus(pastTurnIdx);
    }
    /**
     * Checks if shot is possible given specific parameters
     * @param rowPos the target row position of the shot (int)
     * @param colPos the target col position of the shot (int)
     * @param targetName name of the player targeted  (String)
     * @pre:  rowNumber != null && colNumber != null && targetName != null
     * @return int value referring to a particular scenario
     */
    public int shotIsValid(int rowPos, int colPos, String targetName) {
        //assumes a valid shot
        int scenario = VALID;

        if (!hasPlayer(targetName)) {
            //nonexistent player
            scenario = INVALID_PLAYER_CASE;
        } else {
            //player exists
            Player target = getPlayer(targetName);
            if (getNextPlayer().getName().equals(target.getName())) {
                //self-inflicted shot
                scenario = SELF_HIT_CASE;
            } else if (target.isInactive()) {
                //eliminated player
                scenario = ELIMINATED_PLAYER_CASE;
            } else if (!getPlayer(targetName).isCoordinateInGrid(rowPos, colPos)) {
                //position targeted outside grid bounds
                scenario = INVALID_COORS_CASE;
            }
        }
        return scenario;
    }

    //------------private methods
    /**
     * Changes the Player to carry out the next action
     *
     */
    private void changeTurn() {
        incrementTurn();
        while (players[playerTurnIdx].isInactive()) {
            incrementTurn();
        }
    }
    /**
     * Increases the turn by one player;
     */
    private void incrementTurn() {
        playerTurnIdx = (playerTurnIdx + 1) % players.length;
    }
    
    /**
     * Returns the current turn's player
     * @return the Player object next to engage in the shoot phase
     */
    private Player getNextPlayer() {
        return players[playerTurnIdx];
    }

    /**
     * Compares name value of the Player objects within BattleShips object
     * to find a match for the parameter value
     * @param playerName the name of the player to be retrieved (String)
     * @pre:  hasPlayer(playerName)
     * @return the Player object for a given name
     */
    private Player getPlayer(String playerName) {
        int idx = 0;
        while(idx < players.length && !playerName.equals(players[idx].getName())){
            idx++;
        }
        return players[idx];
    }

    /**
     * Checks for a winner each turn and modifies the object's winnerIdx value
     * @param pastTurnIdx the index of the previous turn's attacking player
     */
    private void updateWinStatus(int pastTurnIdx) {
        if (playerTurnIdx == pastTurnIdx) {
            applyBonus();
            //retrieves player with highest score
            int highestScore = players[0].getScore();
            int highScoreIdx = 0;
            int numHsPlayers = 1; //Hs -> High-score
            for (int i = 1; i < players.length; i++) {
                int playerScore = players[i].getScore();
                if (playerScore > highestScore) {
                    highestScore = playerScore;
                    highScoreIdx = i;
                    numHsPlayers = 1;
                } else if (playerScore == highestScore) {
                    numHsPlayers++;
                }
            }
            if(numHsPlayers > 1) {
                winnerIdx = playerTurnIdx;
            } else {
                winnerIdx = highScoreIdx;
            }
        }
    }
    /**
     * Bonus - doubles score of surviving player before calculating winner
     */
    private void applyBonus(){
        Player survivor = players[playerTurnIdx];
        survivor.addScore(survivor.getScore());
    }
}
