public class FleetIterator {
    /**
     * @authors Diogo Antunes(67763) & Felipe Magno(67994)
     * An object that can be used to iterate over a fleet's values
     */
    private final char[][] matrix;
    private int nextRow;

    public FleetIterator(char[][] matrix){
        this.matrix = matrix;
        nextRow = 0;
    }

    /**
     * Checks for the presence of another row
     * @pre: nextRow >= 0 && matrix != null
     * @return true if there is a next row
     */
    public boolean hasNext(){
        return nextRow < matrix.length;
    }

    /**
     * Returns the next row of the fleet as a String
     * @pre: hasNext() == true && matrix != null
     * @return next row as a String
     */
    public String next(){
        return new String(matrix[nextRow++]);
    }
}

//da pra contar tudo no comeco no fleet layout e depois passar pro player