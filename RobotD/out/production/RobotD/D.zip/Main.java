import java.util.Scanner;

public class Main {

    public static void main(String[] args){
        Scanner in = new Scanner(System.in);

        //setting position variables
        int x1 = in.nextInt();
        int y1 = in.nextInt();

        int x2 = in.nextInt();
        int y2 = in.nextInt();

        in.nextLine();

        Robot r1 = new Robot(x1, y1);
        Robot r2 = new Robot(x2, y2);

        processCommmand(in, r1, r2);
        processCommmand(in, r1, r2);
        processCommmand(in, r1, r2);
        processCommmand(in, r1, r2);

        in.close();
    }

    private static void processCommmand(Scanner in, Robot r1, Robot r2){
        String command = in.next().toUpperCase();

        Robot mainRobot, otherRobot;
        int i = in.nextInt();

        if (i == 1){
            mainRobot = r1;
            otherRobot = r2;
        } else {
            mainRobot = r2;
            otherRobot = r1;
        }

        switch (command){
            case "MOVE":
                processMove(in, mainRobot, otherRobot, i);
                break;
            case "COLLISION":
                processCollision(in, mainRobot, otherRobot);
                break;
            case "POSITION":
                processPosition(mainRobot, i);
                break;
        }
        in.nextLine();
    }

    private static void processMove(Scanner in, Robot mainRobot, Robot otherRobot, int i){

        int distance = in.nextInt();
        int direction = in.nextInt();

        if (mainRobot.willCollide(otherRobot,distance,direction)){
            System.out.printf("Collision detected. Robot %d could not move.\n",i);
        }
        else {
            int moved = mainRobot.move(i, distance, direction);

            if (moved == 0){
                System.out.printf("Wall detected. Robot %d could not move.\n",i);
            }
            else if (moved < distance){
                System.out.printf("Wall detected. Robot %d moved %d meters.\n",i,moved);
            }
            else {
                System.out.printf("Robot %d moved successfully.\n",i);
            }
        }
    }

    private static void processCollision(Scanner in,Robot mainRobot, Robot otherRobot) {

        int distance = in.nextInt();
        int direction = in.nextInt();

        if (mainRobot.willCollide(otherRobot, distance, direction)) {
            System.out.println("Robots will collide.");
        } else {
            System.out.println("Robots will not collide.");
        }
    }

    private static void processPosition(Robot mainRobot, int i){
        int y = mainRobot.getY();
        int x = mainRobot.getX();
        System.out.printf("Robot %d is at the position (%d,%d).\n",i,x,y);
    }

}