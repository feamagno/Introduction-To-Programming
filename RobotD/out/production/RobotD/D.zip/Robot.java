public class Robot {

    //setting constants
    private static final int N = 100;
    private static final int M = 100;
    private static final int MIN = 1;

    private static final int UP = 1;
    private static final int DOWN = 2;
    private static final int RIGHT = 3;
    private static final int LEFT = 4;

    //setting variables
    private int x, y;

    public Robot(int x, int y){
        //constructor
        this.x = x;
        this.y = y;
    }

    public int getX(){
        return this.x;
    }

    public int getY(){
        return this.y;
    }

    public boolean willCollide(Robot other, int distance, int direction){

        int ox = other.getX();
        int oy = other.getY();

        boolean collision = false;

        int dx = this.x - ox;
        int dy = this.y - oy;
//        System.out.println(direction);
//        System.out.printf("dy:%d ",dy);
//        System.out.printf("dx:%d ",dx);
//        System.out.printf("y:%d ",y);
//        System.out.printf("x:%d ",x);
//        System.out.printf("oy:%d ",oy);
//        System.out.printf("ox:%d ",ox);
//        System.out.println(distance);

        switch (direction){
            case UP -> {
                collision = ((dx == 0) && (dy < 0) && ((y + distance) >= oy ));
            }
            case DOWN -> {
                collision = ((dx == 0) && (dy > 0) && ((y - distance) <= oy ));
            }
            case RIGHT -> {
                collision = ((dy == 0) && (dx < 0) && ((x + distance) >= ox ));
            }
            case LEFT -> {
                collision = ((dy == 0) && (dx > 0) && ((x - distance) <= ox ));
            }
        }
//        System.out.println(collision);
        return collision;
    }

    //assuming robots won't collide
    public int move(int i, int distance, int direction){
        int old_y = this.y;
        int old_x = this.x;
        int moved = 0;
        switch (direction){
            case UP -> {
                y = Math.min(this.y + distance, M);
            }
            case DOWN ->{
                y = Math.max(this.y - distance, MIN);
            }
            case RIGHT -> {
                x = Math.min(this.x + distance, N);
            }
            case LEFT ->  {
                x = Math.max(this.x - distance, MIN);
            }
        }
        moved = Math.abs(y - old_y) + Math.abs(x - old_x);
        return moved;
    }
}
