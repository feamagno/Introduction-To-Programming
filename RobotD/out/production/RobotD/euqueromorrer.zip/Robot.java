public class Robot {

    //setting constants
    private static final int N = 100;
    private static final int M = 100;
    private static final int MIN = 1;

    private static final int UP = 1;
    private static final int DOWN = 2;
    private static final int RIGHT = 3;
    private static final int LEFT = 4;

    //setting variables
    private int x, y, aut, pseudoX, pseudoY, pseudoAut;

    public Robot(int x, int y, int aut){
        //constructor
        this.x = x;
        this.y = y;
        this.aut = aut;
    }

    public int getX(){
        return this.x;
    }

    public int getY(){
        return this.y;
    }

    public boolean willCollide(Robot other, int distance, int direction){
        //returns true if robots collide

        int ox = other.getX();
        int oy = other.getY();

        boolean collision = false;

        int dx = this.x - ox;
        int dy = this.y - oy;

        switch (direction){
            case UP -> {
                collision = ((dx == 0) && (dy < 0) && ((y + distance) >= oy ));
            }
            case DOWN -> {
                collision = ((dx == 0) && (dy > 0) && ((y - distance) <= oy ));
            }
            case RIGHT -> {
                collision = ((dy == 0) && (dx < 0) && ((x + distance) >= ox ));
            }
            case LEFT -> {
                collision = ((dy == 0) && (dx > 0) && ((x - distance) <= ox ));
            }
        }
        return collision;
    }

    public boolean hasBattery(int distance,int aut){

        return (distance <= aut);
    }

    //assuming robots won't collide
    //checks if robot has autonomy to do so
    public int move(int distance, int direction, boolean isMoving){

        int old_y, old_x, movey, movex;

        if (isMoving) {
            old_y = this.y;
            old_x = this.x;
            movey = this.y;
            movex = this.x;
        }
        else {
            old_y = this.pseudoY;
            old_x = this.pseudoX;
            movey = this.pseudoY;
            movex = this.pseudoX;
        }

        int moved = 0;

        switch (direction){
            case UP -> {
                movey = Math.min(this.y + distance, M);
            }
            case DOWN ->{
                movey = Math.max(this.y - distance, MIN);
            }
            case RIGHT -> {
                movex = Math.min(this.x + distance, N);
            }
            case LEFT ->  {
                movex = Math.max(this.x - distance, MIN);
            }
        }

        moved = Math.abs(movey - old_y) + Math.abs(movex - old_x);

        if (this.hasBattery(moved, aut)){
            if(isMoving) {
                this.x = movex;
                this.y = movey;
                this.aut -= moved;
            }
            else {
                this.pseudoX = movex;
                this.pseudoY = movey;
                this.pseudoAut -= moved;
            }
        }
        else {
            moved = -1;
        }

        return moved;
    }

    public int closestWall(Robot other){

        int horizontal, vertical, direction, hdirection, vdirection;

        //checking which side is the closest (vertical)
        if (this.y >= (M/2)){
            vdirection = UP;
        } else {vdirection = DOWN;}

        //checking which side is the closest (horizontal)
        if (this.x >= (N/2)){
            hdirection = RIGHT;
        } else {hdirection = LEFT;}

        //calculating distance to closest wall (vertical)
        if (vdirection == UP){
            vertical = Math.abs(this.y - M);
        }
        else {
            vertical = Math.abs(this.y - MIN);
        }
        //calculating distance to closest wall (vertical)
        if (hdirection == RIGHT){
            horizontal = Math.abs(this.x - N);
        }
        else {
            horizontal = Math.abs((this.x - MIN));
        }

        /*
            vertical checks if robot will collide
            if does and is at position y == (M/2) robot will automatically return DOWN
            if it does and is at any other point, vertical value = -1
        */
        if (this.willCollide(other, M, vdirection)){
            if (this.y == (M/2)){
                vdirection = DOWN;
            } else {
                vertical = -1;
            }
        }
        /*
            horizontal checks if robot will collide
            if it does and x == N/50 hdirection is equal to the other direction
            if it does and x =/= horizontal value equals to -1
        */
        if (this.willCollide(other, M, hdirection)){
            if (this.x == (N/2)){
                hdirection = LEFT;
            } else {
                horizontal = -1;
            }
        }

        //checks if there is a collision
        if ((horizontal > 0)&&(vertical>0)) {

            //considering there isn't a collision, checks which side is closest to wall
            if (horizontal > vertical) {
                direction = vdirection;
            }
            //if they are at the same distance, horizontal int are lower and have priority
            else if (horizontal == vertical) {
                direction = vdirection;
            }
            else {
                direction = hdirection;
            }
        }
        else {

            //considering there is a collision, returns other side
            if (vertical < 0){
                direction = hdirection;
            }
            else {
                direction = vdirection;
            }
        }
        return direction;
    }

    public boolean robotReturn(Robot other,int aut ,int x ,int y){

        int direction = this.closestWall(other), distance;

        switch (direction) {
            case 1 -> distance = Math.abs(y - M);
            case 2 -> distance = Math.abs(y - MIN);
            case 3 -> distance = Math.abs(x - N);
            case 4 -> distance = Math.abs(x - MIN);
            default -> distance = 0;
        }

       return this.hasBattery(distance,aut);
    }

    public boolean survey(Robot other, int xi, int yi){

        boolean survey, wontCollide, firstMovement, returning;

        this.pseudoAut = this.aut;
        this.pseudoX = this.x;
        this.pseudoY = this.y;

        //checking if robots will collide (from x y to xi yi)
        //they would only collide if the robot is at the position survey wants to get
        //returns false if robots would collide
        wontCollide = !((other.getX()==xi)&&(other.getY()==yi));

        //setting up distance and direction to use move
        int x = xi - this.x;
        int y = yi - this.y;

        int xDistance = Math.abs(x);
        int yDistance = Math.abs(y);

        int xDirection;
        int yDirection;

        if (y >= 0){
            yDirection = 1;
        }
        else {
            yDirection = 2;
        }

        if (x >= 0){
            xDirection = 3;
        }
        else {
            xDirection = 4;
        }

        //checking if moving is possible
        //if variable move is < 0, robot doesn't have autonomy to do the first movement
        //if move is possible, firstMovement = true;
        int xMove = this.move(xDistance,xDirection,false);
        int yMove = this.move(yDistance,yDirection,false);

        int move = xMove*yMove;

        firstMovement = (move>0);

        //checking if returning is possible
        returning = this.robotReturn(other,this.pseudoAut, this.pseudoX, this.pseudoY);

        //checking if everything is possible
        survey = (wontCollide && firstMovement && returning);

        return survey;
    }
}